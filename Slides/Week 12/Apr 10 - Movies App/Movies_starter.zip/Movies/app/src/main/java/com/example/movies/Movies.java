package com.example.movies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

class Movie {
    String name;
    String year;
    String director;
    Movie(String name, String year) {
        this.name = name;
        this.year = year;
        this.director = "";
    }
    Movie(String name, String year, String director) {
        this(name, year);
        this.director = director;
    }
    public String toString() {   // used by ListView
        return name + "\n(" + year + ")";
    }
    public String getString() {
        return name + "|" + year + "|" + director;
    }
}

public class Movies extends AppCompatActivity {

    private ListView listView;
    private ArrayList<Movie> movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movies_list);

        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        String[] moviesList = getResources().getStringArray(R.array.movies_array);
        movies = new ArrayList<>(moviesList.length);
        for (String movie: moviesList) {
            String[] tokens = movie.split("\\|");
            movies.add(new Movie(tokens[0], tokens[1]));
        }

        listView = findViewById(R.id.movies_list);
        listView.setAdapter(
                new ArrayAdapter<>(this, R.layout.movie, movies));
    }
}