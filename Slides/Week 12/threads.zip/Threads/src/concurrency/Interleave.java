package concurrency;

public class Interleave implements Runnable {

	public Interleave(String name) {
		new Thread(this, name).start();
	}
	
	public void run() {
		for (int i=0; i < 4; i++) {
			System.out.println(Thread.currentThread().getName());
			try {
				Thread.sleep((int)Math.random()*1000);
			} catch (InterruptedException e) {}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Interleave("java");
		new Interleave("sumatra");
	}

}
