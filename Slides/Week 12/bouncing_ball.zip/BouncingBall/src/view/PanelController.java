package view;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;

public class PanelController implements Initializable, Runnable {

	@FXML Button slower;
	@FXML Button faster;
	@FXML Button pause;
	@FXML Button resume;
	@FXML Canvas panel;
	
	public static final int DELAY = 100;
	
	int delay = DELAY;
	
	Thread animatorThread = null;
	
	GraphicsContext gc;
	
	public void tweak(ActionEvent e) {
		Button b = (Button)e.getSource();
		if (b == slower) {
			delay += 10;
		} else if (b == faster) {
			if (delay > 50) {
				delay -= 10;
			}
		} else if (b == resume) {
			animatorThread = new Thread(this); 
			animatorThread.start();
		} else if (b == pause) {
			animatorThread.interrupt();
		}
	}
	
	@Override
    public void initialize(URL location, ResourceBundle resources) {
		gc = panel.getGraphicsContext2D();
		animatorThread = new Thread(this);
		animatorThread.start();
	}
	
	public void run() {
		long startTime = System.currentTimeMillis();
		
		// animation loop
		while (!Thread.interrupted()) {
			paintCanvas();
			
			try {
				startTime += delay;
				Thread.sleep(Math.max(0, startTime - 
						System.currentTimeMillis()));
			} catch (InterruptedException e) {
				break;
			}
		}
	}
	
	int radius = 60;
	int unitWidth = 2*radius;
	int displayWidth = 8*unitWidth;
	int displayHeight = 4*radius;
	
	boolean rising = false;
	int ballX = displayWidth - unitWidth;
	int ballY = 3*radius;
	
	public static int XOFF = 10;
	public static int YOFF = 10;
	
	public void paintCanvas() {
		gc.setFill(Color.BLUE);
		gc.fillRect(XOFF, YOFF, displayWidth, displayHeight);
		
		gc.setFill(Color.YELLOW);
		
		ballX += unitWidth;
		if (ballX == displayWidth) {
			gc.fillArc(XOFF + displayWidth - radius,
					YOFF + displayHeight - 3*radius,
					2*radius, 2*radius, 90, 180, ArcType.ROUND);
			gc.fillArc(XOFF - radius,
					YOFF + displayHeight - 3*radius,
					2*radius, 2*radius, 90, -180, ArcType.ROUND);
			ballX = 0;
			ballY = 0;
			rising = true;
			return;
		}
		
		if (rising) {
			ballY += radius;
			if (ballY == (displayHeight - radius)) rising = false;
		} else {
			ballY -= radius;
			if (ballY == radius) rising = true;
		}
		gc.fillOval(XOFF + ballX - radius, 
				YOFF + displayHeight - ballY - radius,
				2*radius, 2*radius);
	}
	
	public void stop() {
		animatorThread.interrupt();
	}
}
