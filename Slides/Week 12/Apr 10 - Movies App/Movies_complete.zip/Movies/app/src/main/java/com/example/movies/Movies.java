package com.example.movies;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

class Movie {
    String name;
    String year;
    String director;
    Movie(String name, String year) {
        this.name = name;
        this.year = year;
        this.director = "";
    }
    Movie(String name, String year, String director) {
        this(name, year);
        this.director = director;
    }
    public String toString() {   // used by ListView
        return name + "\n(" + year + ")";
    }
    public String getString() {
        return name + "|" + year + "|" + director;
    }
}

public class Movies extends AppCompatActivity {

    private ListView listView;
    private ArrayList<Movie> movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movies_list);

        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        try {
            FileInputStream fis = openFileInput("movies.dat");
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(fis));
            String movieInfo=null;
            movies = new ArrayList<Movie>();
            while ((movieInfo = br.readLine()) != null) {
                String[] tokens = movieInfo.split("\\|");
                if (tokens.length == 3) {
                    movies.add(new Movie(tokens[0],tokens[1], tokens[2]));
                } else {
                    movies.add(new Movie(tokens[0], tokens[1]));
                }
            }
        } catch (IOException e) {
            String[] moviesList = getResources().getStringArray(R.array.movies_array);
            movies = new ArrayList<>(moviesList.length);
            for (String movie : moviesList) {
                String[] tokens = movie.split("\\|");
                movies.add(new Movie(tokens[0], tokens[1]));
            }
        }
        listView = findViewById(R.id.movies_list);
        listView.setAdapter(
                new ArrayAdapter<>(this, R.layout.movie, movies));

        listView.setOnItemClickListener((list, view, pos, id) -> showMovie(pos));

        // register add/edit activities in onCreate
        // registration must be done before creation is completed
        registerActivities();
    }

    private ActivityResultLauncher<Intent> startForResultEdit;
    private ActivityResultLauncher<Intent> startForResultAdd;
    public void registerActivities() {
        startForResultEdit =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                applyEdit(result, "edit");
                            }
                        });

        startForResultAdd =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                applyEdit(result, "add");
                            }
                        });
    }

    private void applyEdit(ActivityResult result, String addEdit) {
        Intent intent = result.getData();
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            return;
        }

        // gather all info passed back by launched activity
        String name = bundle.getString(AddEditMovie.MOVIE_NAME);
        String year = bundle.getString(AddEditMovie.MOVIE_YEAR);
        String director = bundle.getString(AddEditMovie.MOVIE_DIRECTOR);
        int index = bundle.getInt(AddEditMovie.MOVIE_INDEX);
        if (addEdit.equals("edit")) {
            // update the movie
            Movie movie = movies.get(index);
            movie.name = name;
            movie.year = year;
            movie.director = director;
        } else if (addEdit.equals("add")){
            movies.add(new Movie(name, year, director));
        }

        // redo the adapter to reflect change
        listView.setAdapter(new ArrayAdapter<Movie>(this, R.layout.movie, movies));
    }

    private void showMovie(int pos) {
        Bundle bundle = new Bundle();
        Movie movie = movies.get(pos);
        bundle.putInt(AddEditMovie.MOVIE_INDEX, pos);
        bundle.putString(AddEditMovie.MOVIE_NAME, movie.name);
        bundle.putString(AddEditMovie.MOVIE_YEAR, movie.year);
        bundle.putString(AddEditMovie.MOVIE_DIRECTOR, movie.director);

        // launch for edit
        Intent intent = new Intent(this, AddEditMovie.class);
        intent.putExtras(bundle);
        startForResultEdit.launch(intent);
    }

    private void addMovie() {
        // launch for add
        Intent intent = new Intent(this, AddEditMovie.class);
        startForResultAdd.launch(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                addMovie();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}