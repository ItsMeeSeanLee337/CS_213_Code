package primes;

import java.util.Scanner;

public class PrimesThread extends Thread {

	static int count=0, p;
	int n;
	
	public PrimesThread(int n) {
		this.n = n;
		start();   // MUST call start to run in separate thread!!!
	}
	
	public void run() {
		p = 2;
		while (p <= n) {
			int d;
			for (d=2; d <= p/2; d++) {
				if ((p % d) == 0) {
					break;
				}
			}
			if (d > p/2) {
				count++;
			}
			p++;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter n: ");
        int n = Integer.parseInt(sc.nextLine());
        
        
        new PrimesThread(n);  // launch independent thread to compute primes
        
        while (true) {
        	System.out.print("? ");
        	String line = sc.nextLine();
        	if (line.equals("quit")) {
        		break;
        	}
        	System.out.println("At " + (p-1) + ", number of primes = " + count);	
        }
        System.out.println("At " + (p-1) + ", number of primes = " + count);        
                
        sc.close();

       
	}

}
